#!/usr/bin/env python3
import sys
import math


#TODO

for line in sys.stdin:
    # TODO
    print(line.strip())
#TODO
# print('%s\t%s' % (  ,  )) print as final output
