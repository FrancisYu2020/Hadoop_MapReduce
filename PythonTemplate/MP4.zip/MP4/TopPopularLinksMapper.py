#!/usr/bin/env python3
import sys


# TODO



for line in sys.stdin:

       #TODO
       # print(line)
       line = line.strip()
       print('%s\t%s' % ('None', line))


#TODO
# print('%s\t%s' % (  ,  )) pass this output to reducer
